package drib::dist::remote;

# what we need
use HTTP::Request;
use Digest::MD5 qw(md5_hex);
use JSON;
use Data::Dumper;

# version
my $VERSION = "0.0.1";

# some constants
use constant API_HOST => "http://67.23.31.44";
use constant API_PORT => 4080;
use constant API_VERSION => "1";

sub new {

	# get 
	my($key,$secret,$project) = @_;

	# get myself
	my $self = {};
	
	# add some properties
	$self->{project} = $project;
	$self->{key} = $key;
	$self->{secret} = $secret;
	$self->{host} = API_HOST;
	$self->{port} = API_PORT;
	$self->{version} = API_VERSION;
	
	# bless and return me
	bless($self); return $self;

}

sub check {

	my ($self,$pkg,$ver) = @_;
	
	# make a package name
	my $name = $pkg."-".$ver;

	# get 
	my $resp = $self->get({
	   'end' => "package/$name"
    });
    
    print $resp; die;

}

sub get {

	my ($self,$args) = @_;
	
    # where should we end
	my $endpoint = $args->{end};
	my $method = $args->{method} || 'GET';

    # module 
    my @parts = split(/\//,$endpoint);
    my $module = shift @parts;
    my $path = join('/',@parts);
    
    # sig
    my $sig = md5_hex($self->{secret}.$module.$method.$path);

	# url
	my $url = $self->{host} . ":" . $self->{port} . "/v" . $self->{version} . "/" . $endpoint;

    # yes 
    my $req = HTTP::Request->new($method => $url);    
    
    # add some headers
    $req->header('x-drib-key'=>$self->{key});
    $req->header('x-drib-sig'=>$sig);
    
    # content 
    if ( $args->{content} ) {
        $req->content($args->{content});
    }

    # ua
    use LWP::UserAgent;
    
    # add a ua
    my $ua = LWP::UserAgent->new;

    # Pass request to the user agent and get a response back
    my $res = $ua->request($req);
    
    print Dumper($res->content); die;
    
    # Check the outcome of the response
    if ($res->is_success) {
        return $res->content;
    }
    else {
        return 0;
    }    

}
package drib::dist::local;

use utils;
use Data::Dumper;

# version
my $VERSION = "0.0.1";

use constant BASE_DIR => "/home/drib/dist/";

sub new {

	# get some
	my ($user) = @_;

	# get myself
	my $self = {};
	
	# add some properties
	$self->{folder} = BASE_DIR;
	$self->{user} = $user;
	
	# bless and return me
	bless($self); return $self;

}

sub check {

	my ($self,$pkg,$ver) = @_;
	
	# make a package name
	my $name = $pkg."-".$ver.".tar.gz";

	# check if the file exists
	if ( -e $self->{folder} . "$pkg/$name" ) {
		return 1;
	}
	else {
		return 0;
	}

}

sub get {

	my ($self,$pkg,$ver) = @_;
	
	# make a package name
	my $name = $pkg."-".$ver.".tar.gz";

	# check 
	if ( !$self->check($pkg,$ver) ) {
		return 0;
	}

	# get get
	$file = file_get( $self->{folder} . "/$pkg/$name" );

}

sub upload {

	my ($self,$info) = @_;
	
	# get from info
	my $user = $info->{username};
	my $pkg = $info->{name};
	my $version = $info->{version};
	my $branch = $info->{branch};
	my $tar = $info->{tar};
	
	# package directory
	my $dir = $self->{folder} . $user . "/". $pkg . "/";
	my $name = "$pkg-$version.tar.gz";

	# see if the directory exists
	unless ( -d $dir ) {
		`sudo mkdir -p $dir`;
	} 
	
	# save this version
	file_put($dir.$name,$tar);

	# now remove the current branch version
	unlink $dir."$pkg-$branch.tar.gz";

	# set it
	file_put($dir."$pkg-$branch.tar.gz",$tar);

	# done
	return 1;

}